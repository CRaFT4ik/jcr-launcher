package ru.er_log.components;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import ru.er_log.Settings;
import ru.er_log.utils.BaseUtils;
import ru.er_log.utils.StyleUtils;

public class TextField extends JTextField {
    
    public Panel pb;
    public BufferedImage image;
    public int width = 0;
    public int height = 0;
    public int x = 0;
    public int y = 0;
    
    public TextField(int x, int y, int width, int height, Color color)
    {       
	setOpaque(false);
	setBorder(null);
	setCaretColor(color);
	setForeground(color);
        setSelectionColor(new Color(51, 153, 255));
        setSelectedTextColor(Color.WHITE);
        setHorizontalAlignment(LEFT);
        setFont(StyleUtils.getFont(14, 1));
        setBounds(x+16, y, width-32, height);
        
        this.width = width - 32;
        this.height = height;
        this.x = x;
        this.y = y;
        
        pb = new Panel();
        pb.DrawLoginField(height, y);
    }
    
    public TextField(int x, int y, int width, int height, String str, final int maxlength, Color color)
    {
	setOpaque(false);
	setBorder(null);
	setCaretColor(color);
	setForeground(color);
        setSelectionColor(new Color(51, 153, 255));
        setSelectedTextColor(Color.WHITE);
        setHorizontalAlignment(CENTER);
        setFont(StyleUtils.getFont(12, 1));
        setBounds(x, y, width, height);
        
        setDocument(new PlainDocument()
        {
            public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException
            {
                if (str == null) return;
                if ((getLength() + str.length()) <= maxlength) super.insertString(offset, str, attr);
            }
        }); setText(str);
        
        this.image = BaseUtils.fieldBack;
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
    }
    
    protected void paintComponent(Graphics g)
    {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        if(image != null) { g2d.drawImage(image, 0, 0, null); }
        
        if(Settings.drawBorders)
        {
            g2d.setColor(Color.GRAY);
            g2d.drawRect(0, 0, width - 1, height - 1);
        }
        
        g2d.dispose();
        super.paintComponent(g);
    }
}
