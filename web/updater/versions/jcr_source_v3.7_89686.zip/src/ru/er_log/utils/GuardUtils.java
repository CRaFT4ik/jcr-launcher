package ru.er_log.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.Formatter;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import ru.er_log.Settings;
import ru.er_log.Starter;
import ru.er_log.components.Frame;
import ru.er_log.game.Game;

public class GuardUtils {
    
    public static String md5(String s)
    {
        String hash = null;
        try
        {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(s.getBytes(), 0, s.length());
            hash = new BigInteger(1, m.digest()).toString(16);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        return hash;
    }
    
    public static String sha1(String input)
    {
        String hash = null;
        try
        {
            MessageDigest m = MessageDigest.getInstance("SHA1");
            byte[] result = m.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < result.length; i++)
            {
                sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
            }
            hash = sb.toString();
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        return hash;
    }
    
    public static String md5_file(String filename)
    {
        FileInputStream fis = null;
        DigestInputStream dis = null;
        BufferedInputStream bis = null;
        Formatter formatter = null;
        try
        {
            MessageDigest messagedigest = MessageDigest.getInstance("MD5");
            fis = new FileInputStream(filename);
            bis = new BufferedInputStream(fis);
            dis = new DigestInputStream(bis, messagedigest);
            while (dis.read() != -1);
            byte abyte0[] = messagedigest.digest();
            formatter = new Formatter();
            byte abyte1[] = abyte0;
            int i = abyte1.length;
            for (int j = 0; j < i; j++)
            {
                byte byte0 = abyte1[j];
                formatter.format("%02x", new Object[] { Byte.valueOf(byte0) });
            }
            return formatter.toString();
        } catch (Exception e)
        {
            return "";
        } finally
        {
            try { fis.close(); } catch (Exception e) {}
            try { dis.close(); } catch (Exception e) {}
            try { bis.close(); } catch (Exception e) {}
            try { formatter.close(); } catch (Exception e) {}
        }
    }
    
    public static String appPath()
    {
        try { return Starter.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath(); }
        catch (Exception e) { e.printStackTrace(); return null; }
    }
    
    public static boolean checkFilesMods(final String[] data)
    {
        boolean clean = true;
        if (!Settings.useModCheck) return true;
        
        String[] data_mods = data[9].split("<:m:>");
        String[] names_mods = new String[data_mods.length];
        String[] hashes_mods = new String[data_mods.length];
        
        if (!data[9].equals("nomods"))
        for (int i = 0; i < data_mods.length; i++)
        {
            names_mods[i] = data_mods[i].split("<:h:>")[0];
            hashes_mods[i] = data_mods[i].split("<:h:>")[1];
        }
        
        Frame.report("GUARD: Проверка модификаций в папке \"mods\"...");
        File path = new File(BaseUtils.getClientDirectory() + File.separator + "mods");
        String[] dirFiles = path.list();
        if (dirFiles == null || dirFiles.length == 0) return true;
        
        if (data[9].equals("nomods"))
        {
            for (int i = 0; i < dirFiles.length; i++)
            {
                File file = new File(path + File.separator + dirFiles[i]);
                BaseUtils.delete(file); String mes = "";
                if (!file.exists()) mes = "и удален ";
                Frame.report("GUARD: Обнаружен " + mes + "сторонний объект: " + dirFiles[i]);
                clean = false;
            }
        } else if (Settings.removeAllFiles)
        {
            for (int i = 0; i < dirFiles.length; i++)
            {
                if (BaseUtils.findString(names_mods, dirFiles[i]) == -1)
                {
                    File file = new File(path + File.separator + dirFiles[i]);
                    BaseUtils.delete(file); String mes = "";
                    if (!file.exists()) mes = "и удален ";
                    Frame.report("GUARD: Обнаружен " + mes + "сторонний объект: " + dirFiles[i]);
                    clean = false;
                }
            }
        } else
        {
            String[] modsFiles = path.list(new FilenameFilter() { public boolean accept(File folder, String name)
                { return name.toLowerCase().endsWith(".zip") || name.toLowerCase().endsWith(".jar"); }});
            
            for (int i = 0; i < modsFiles.length; i++)
            {
                if (BaseUtils.findString(names_mods, modsFiles[i]) == -1)
                {
                    File file = new File(path + File.separator + modsFiles[i]);
                    BaseUtils.delete(file); String mes = "";
                    if (!file.exists()) mes = "и удалена ";
                    Frame.report("GUARD: Обнаружена " + mes + "сторонняя модификация: " + modsFiles[i]);
                    clean = false;
                }
            }
        }
        
        if (Settings.useCheckModsHashes)
        for (int i = 0; i < names_mods.length; i++)
        {
            File file = new File(path + File.separator + names_mods[i]);
            if (!hashes_mods[i].equals(md5_file(file.toString())))
            {
                file.delete(); String mes = "";
                if (!file.exists()) mes = "и удален ";
                Frame.report("GUARD: Обнаружен " + mes + "файл подменённого мода: " + names_mods[i]);
                clean = false;
            }
        }
        
        return clean;
    }
    
    public static boolean checkFilesCoreMods(String[] data)
    {
        boolean clean = true;
        if (!Settings.useModCheck) return true;
        
        String[] data_mods = data[13].split("<:m:>");
        String[] names_mods = new String[data_mods.length];
        String[] hashes_mods = new String[data_mods.length];
        
        if (!data[13].equals("nocoremods"))
        for (int i = 0; i < data_mods.length; i++)
        {
            names_mods[i] = data_mods[i].split("<:h:>")[0];
            hashes_mods[i] = data_mods[i].split("<:h:>")[1];
        }
        
        Frame.report("GUARD: Проверка модификаций в папке \"coremods\"...");
        File path = new File(BaseUtils.getClientDirectory() + File.separator + "coremods");
        String[] dirFiles = path.list();
        if (dirFiles == null || dirFiles.length == 0) return true;
        
        if (data[13].equals("nocoremods"))
        {
            for (int i = 0; i < dirFiles.length; i++)
            {
                File file = new File(path + File.separator + dirFiles[i]);
                BaseUtils.delete(file); String mes = "";
                if (!file.exists()) mes = "и удален ";
                Frame.report("GUARD: Обнаружен " + mes + "сторонний объект: " + dirFiles[i]);
                clean = false;
            }
        } else if (Settings.removeAllFiles)
        {
            for (int i = 0; i < dirFiles.length; i++)
            {
                if (BaseUtils.findString(names_mods, dirFiles[i]) == -1)
                {
                    File file = new File(path + File.separator + dirFiles[i]);
                    BaseUtils.delete(file); String mes = "";
                    if (!file.exists()) mes = "и удален ";
                    Frame.report("GUARD: Обнаружен " + mes + "сторонний объект: " + dirFiles[i]);
                    clean = false;
                }
            }
        } else
        {
            String[] modsFiles = path.list(new FilenameFilter() { public boolean accept(File folder, String name)
                { return name.toLowerCase().endsWith(".zip") || name.toLowerCase().endsWith(".jar"); }});
            
            for (int i = 0; i < modsFiles.length; i++)
            {
                if (BaseUtils.findString(names_mods, modsFiles[i]) == -1)
                {
                    File file = new File(path + File.separator + modsFiles[i]);
                    BaseUtils.delete(file); String mes = "";
                    if (!file.exists()) mes = "и удалена ";
                    Frame.report("GUARD: Обнаружена " + mes + "сторонняя модификация: " + modsFiles[i]);
                    clean = false;
                }
            }
        }
        
        if (Settings.useCheckModsHashes)
        for (int i = 0; i < names_mods.length; i++)
        {
            File file = new File(path + File.separator + names_mods[i]);
            if (!hashes_mods[i].equals(md5_file(file.toString())))
            {
                file.delete(); String mes = "";
                if (!file.exists()) mes = "и удален ";
                Frame.report("GUARD: Обнаружен " + mes + "файл подменённого мода: " + names_mods[i]);
                clean = false;
            }
        }
        
        return clean;
    }
    
    public static void checkClient(String[] data, boolean firstCheck)
    {
        if (!Frame.frame.set_offline.isSelected())
        {
            Frame.report("GUARD: Проверка файлов игры...");
            boolean all_clean = true;
            String binfolder = BaseUtils.getClientDirectory() + File.separator + "bin" + File.separator;
            if (!data[1].equals(md5_file(binfolder + "minecraft.jar"))) all_clean = false;
            if (!data[2].equals(md5_file(binfolder + "lwjgl.jar"))) all_clean = false;
            if (!data[3].equals(md5_file(binfolder + "lwjgl_util.jar"))) all_clean = false;
            if (!data[4].equals(md5_file(binfolder + "jinput.jar"))) all_clean = false;
            if (!checkFilesMods(data) || !checkFilesCoreMods(data)) all_clean = false;
            
            if (all_clean)
            {
                Frame.report("GUARD: Проверка завершена успешно");
                return;
            }
            
            if (!firstCheck && !all_clean && Settings.stopDirtyProgram)
            {
                Frame.report("GUARD: Обнаружены посторонние объекты, игровой процесс будет прерван");
                if (Game.applet != null)
                {
                    Game.applet.stop();
                    Game.applet.destroy();
                } System.exit(0);
            }
        }
    }
    
    public static UUID getHWID() throws UnsupportedEncodingException
    {
        String info = null;
        Properties systemProps = System.getProperties();
        Set<Map.Entry<Object, Object>> sets = systemProps.entrySet();
        for (Map.Entry<Object, Object> entry : sets) info = (info + entry.getKey() + entry.getValue());
        return UUID.nameUUIDFromBytes(info.getBytes("UTF-16BE"));
    }
}
