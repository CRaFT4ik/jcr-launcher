package ru.er_log.game;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import ru.er_log.components.Frame;
import ru.er_log.utils.BaseUtils;
import ru.er_log.utils.GuardUtils;
import ru.er_log.utils.ZipUtils;

public class GameUpdater extends Thread {
    
    public int percents = 0;
    public long totalsize = 0;
    public long currentsize = 0;
    public String currentfile = "...";
    public int downloadspeed = 0;
    public List<String> files = new ArrayList<>();
    public String state = "...";
    public boolean zipupdate = false;
    public String[] data;
    
    public GameUpdater(List<String> files, boolean zipupdate, String[] data)
    {
        this.files = files;
        this.zipupdate = zipupdate;
        this.data = data;
    }
    
    @Override
    public void run()
    {
        try
        {
            String pathTo = BaseUtils.getClientDirectory() + File.separator;
            String urlTo = BaseUtils.getURL("files/clients/" + BaseUtils.getClientName() + "/");

            File dir = new File(pathTo + "bin" + File.separator);
            if (!dir.exists()) dir.mkdirs();
            dir = new File(pathTo + "bin" + File.separator + "natives" + File.separator);
            if (!dir.exists()) dir.mkdirs();
            dir = new File(pathTo + "mods" + File.separator);
            if (!dir.exists()) dir.mkdirs();
            dir = new File(pathTo + "coremods" + File.separator);
            if (!dir.exists()) dir.mkdirs();

            state = "вычисление размера...";

            for (int i = 0; i < files.size(); i++)
            {
                URLConnection urlconnection = new URL(urlTo + files.get(i)).openConnection();
                urlconnection.setDefaultUseCaches(false);
                totalsize += urlconnection.getContentLength();
            }

            state = "загрузка файлов...";
            if (!files.isEmpty())
                Frame.report("Запуск процесса загрузки файлов: ");

            byte[] buffer = new byte[65536];
            for (int i = 0; i < files.size(); i++)
            {
                currentfile = files.get(i);
                Frame.report(" * Загрузка файла: " + currentfile);
                InputStream inputstream = new BufferedInputStream(new URL(urlTo + files.get(i)).openStream());
                FileOutputStream fos = new FileOutputStream(pathTo + files.get(i));
                long downloadStartTime = System.currentTimeMillis();
                int downloadedAmount = 0, bufferSize = 0;
                MessageDigest m = MessageDigest.getInstance("MD5");
                while ((bufferSize = inputstream.read(buffer, 0, buffer.length)) != -1)
                {
                    fos.write(buffer, 0, bufferSize);
                    m.update(buffer, 0, bufferSize);
                    currentsize += bufferSize;
                    percents = (int) (currentsize * 100 / totalsize);
                    downloadedAmount += bufferSize;
                    long timeLapse = System.currentTimeMillis() - downloadStartTime;
                    if (timeLapse >= 1000L)
                    {
                        downloadspeed = (int) ((int) (downloadedAmount / (float) timeLapse * 100.0F) / 100.0F);
                        downloadedAmount = 0;
                        downloadStartTime += 1000L;
                    }
                }
                inputstream.close();
                fos.close();
                Frame.report(" * * Файл " + currentfile + " загружен");
            }

            state = "завершение...";

            if (zipupdate)
            {
                String md5h = GuardUtils.md5_file(BaseUtils.getClientDirectory() + File.separator + "extra.zip");
                BaseUtils.setProperty(BaseUtils.getClientName() + "_hashZip", GuardUtils.sha1(md5h));
                ZipUtils.unzip();
            }
            
            new Game(data);
        } catch (Exception e)
        {
            e.printStackTrace();
            state = e.toString();
        }
    }
}
