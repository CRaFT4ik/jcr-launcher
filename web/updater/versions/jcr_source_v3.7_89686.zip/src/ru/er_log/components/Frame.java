package ru.er_log.components;

import com.sun.awt.AWTUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import ru.er_log.Settings;
import ru.er_log.splash.SplashFrame;
import ru.er_log.utils.GuardUtils;
import ru.er_log.utils.ThemeUtils;
import ru.er_log.utils.StreamUtils;
import ru.er_log.utils.ImageUtils;

import static ru.er_log.utils.BaseUtils.*;

/**
 *
 * @author Eldar T. (CRaFT4ik)
 * 
 */
public class Frame extends JFrame implements FocusListener, KeyListener {
    
    public static String[] authData = null;
    public static String[] onlineData = null;
    public static String appHash = "";
    private static int debLine = 1;
    
    public JButton turn  = new JButton();
    public JButton close = new JButton();
    private int X = 0, Y = 0;
    
    public static Frame frame;
    public GuardUtils gu = new GuardUtils();
    public Panel panel = new Panel();
        public ComboBox serversList      = new ComboBox(null, 324);
        public JTextPane news_pane       = new JTextPane();
        public JScrollPane newsScPane    = new JScrollPane(news_pane);
        public JTextField login          = new JTextField();
        public JPasswordField password   = new JPasswordField();
        public JButton toGame            = new JButton("В игру");
        public JButton upd_action        = new JButton("Выход");
        public JButton upd_take          = new JButton("Обновить");
        public JButton doAuth            = new JButton("Войти");
        public JButton settings          = new JButton("Настройки");
            public JButton set_cancel     = new JButton("Отмена");
            public JButton set_take       = new JButton("Принять");
            public JCheckBox set_remember = new JCheckBox("Запомнить мои данные");
            public JCheckBox set_update   = new JCheckBox("Перекачать клиент");
            public JCheckBox set_full     = new JCheckBox("Полноэкранный режим");
            public JCheckBox set_offline  = new JCheckBox("Режим оффлайн");
            public JTextField set_memory  = new JTextField("1024");
            
        
    public Frame()
    {
        if(!Settings.useSysFrame && getPlatform() != 0)
        { this.setUndecorated(true); AWTUtilities.setWindowOpaque(this, false); }
        this.setPreferredSize(new Dimension(Settings.frameWidth, Settings.frameHeight));
        this.setSize(this.getPreferredSize());
        this.setTitle(Settings.title + " :: " + Settings.version);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setIconImage(favicon); mouseListener();
        try { ThemeUtils.updateStyle(this); } catch(Exception e) {}
        
            login.setText(Settings.login_text);
            login.addActionListener(null);
            login.addFocusListener(this);
            
            password.setText(Settings.pass_text);
            password.addActionListener(null);
            password.addFocusListener(this);
            
            news_pane.setOpaque(false);
            news_pane.setBorder(null);
            news_pane.setContentType("text/html");
            news_pane.setEditable(false);
            news_pane.setFocusable(false);
            news_pane.addHyperlinkListener(new HyperlinkListener() {
                public void hyperlinkUpdate(HyperlinkEvent e)
                {
                    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
                    openLink(e.getURL().toString());
                }
            });
            
            newsScPane.setOpaque(false);
            newsScPane.getViewport().setOpaque(false);
            newsScPane.setBorder(null);
            newsScPane.setBounds(Settings.frameWidth + 25, 10 + 35, news_back.getWidth() - 25 * 2, 430 - 35 * 2);
            
            serversList.addMouseListener(new MouseListener()
            {
                public void mouseReleased(MouseEvent e) {}
                public void mousePressed(MouseEvent e) {}
                public void mouseExited(MouseEvent e) {}
                public void mouseEntered(MouseEvent e) {}
                public void mouseClicked(MouseEvent e)
                {
                    if(!serversList.error)
                    {
                        panel.hideAlerts(true);
                        if (serversList.getPressed() || e.getButton() != MouseEvent.BUTTON1) return;
                        
                        if (serversList.getSelectValue())
                        { panel.waitIcon(true); StreamUtils.getServerOnline(); }
                        panel.hideAlerts(false);
                    }
                }
            });
            
          panel.addKeyListener(this);
          login.addKeyListener(this);
          password.addKeyListener(this);
          
          addFrameElements(false);
          addAuthElements(false);
          
        this.setContentPane(panel);
    }
    
    public static void beforeStart()
    {
        report("Запуск JCR Launcher " + Settings.version);
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            report("Установка системного LnF успешно завершена");
        } catch (Exception e)
        { report("Не удалось установить системный LnF"); }
        
        StreamUtils.setAppHash();
        onlineData = loadOnlineSettings();
        setTheme();
    }
    
    public static void start(final SplashFrame sframe)
    {
        frame = new Frame();
        frame.panel.setAuthState();
        
        readConfig(frame);
        if (Settings.useLoadingNews)
        {
            Color c = ThemeElements.tcolor;
            StreamUtils.loadNewsPage(getURLSc("jcr_news.php?color=rgb(" + c.getRed() + "," + c.getGreen() + "," + c.getBlue() + ")"));
        }
        
        if (Settings.useUpdateMon)
        {
            frame.panel.waitIcon(true);
            StreamUtils.getServerOnline();
        }
        
        SwingUtilities.invokeLater(new Runnable()
        { public void run() { if (sframe != null) sframe.dispose(); } });
        
        frame.show();
    }
    
    private void mouseListener()
    {
        this.addMouseMotionListener(new MouseMotionAdapter()
        {
            public void mouseDragged(MouseEvent e)
            {
                setLocation(getX() + e.getX() - X, getY() + e.getY() - Y);
            }
        });
        this.addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e)
            {
                X = e.getX();
                Y = e.getY();
            }
        });
    }
    
    public void elEnabled(boolean enable)
    {
        serversList.setEnabled(enable);
        login.setEnabled(enable);
        password.setEnabled(enable);
        doAuth.setEnabled(enable);
        settings.setEnabled(enable);
        upd_action.setEnabled(enable);
        upd_take.setEnabled(enable);
        set_cancel.setEnabled(enable);
        set_take.setEnabled(enable);
        set_remember.setEnabled(enable);
        set_update.setEnabled(enable);
        set_full.setEnabled(enable);
        set_offline.setEnabled(enable);
        set_memory.setEnabled(enable);
        toGame.setEnabled(enable);
    }
    
    public void toXFrame(int type)
    {
        BufferedImage min = ImageUtils.takePicture(panel).getSubimage(0, 0, panel.getWidth(), panel.getHeight());
        panel.removeAll();
        panel.animation.paneAttenuation(min, type);
        panel.hideAlerts(true);
        addFrameElements(false);
        repaint();
    }
    
    public void paneState(int goTo)
    {
        switch (goTo)
        {
            case 1: panel.setAuthState(); break;
            case 2: panel.setSettings(); break;
            case 3: panel.setUpdateState(); break;
            case 4: panel.setGameUpdateState(); break;
            case 5: panel.setPersonalState(); break;
        }
    }
    
    public void afterFilling(final int aF, boolean remove)
    {
        switch (aF)
        {
            case 1: addAuthElements(remove); break;
            case 2: addSettingsElements(remove); break;
            case 3: addUpdateElements(remove); break;
            case 4: break;
            case 5: addPersonalElements(remove); break;
        }
    }
    
    protected final void addFrameElements(boolean remove)
    {
        if(!remove)
        {
            panel.add(turn);
            panel.add(close);
        } else
        {
            panel.remove(turn);
            panel.remove(close);
        }
    }
    
    protected final void addAuthElements(boolean remove)
    {
        if(!remove)
        {
            panel.add(serversList);
            panel.add(doAuth);
            panel.add(settings);
            panel.add(login);
            panel.add(password);
        } else
        {
            panel.remove(serversList);
            panel.remove(doAuth);
            panel.remove(settings);
            panel.remove(login);
            panel.remove(password);
        }
    }
    
    protected void addSettingsElements(boolean remove)
    {
        if(!remove)
        {
            panel.add(set_cancel);
            panel.add(set_take);
            panel.add(set_remember);
            panel.add(set_update);
            panel.add(set_full);
            panel.add(set_offline);
            panel.add(set_memory);
        } else
        {
            panel.remove(set_cancel);
            panel.remove(set_take);
            panel.remove(set_remember);
            panel.remove(set_update);
            panel.remove(set_full);
            panel.remove(set_offline);
            panel.remove(set_memory);
        }
    }
    
    protected void addUpdateElements(boolean remove)
    {
        if(!remove)
        {
            panel.add(upd_action);
            panel.add(upd_take);
        } else
        {
            panel.remove(upd_action);
            panel.remove(upd_take);
        }
    }
    
    protected void addPersonalElements(boolean remove)
    {
        if(!remove)
        {
            panel.add(toGame);
        } else
        {
            panel.remove(toGame);
        }
    }
    
    public void setAlert(String alert, int type)
    {
        panel.alertIcons(alert, type);
    }
    
    public void setAlert(String alert, int type, int y)
    {
        panel.alertIcons(alert, type, y);
    }
    
    public static void report(String mes)
    {
        if(Settings.useDebugging)
        {
            String num = null;
            if(Integer.toString(debLine).length() == 1) num = "00" + debLine + ": ";
            else if(Integer.toString(debLine).length() == 2) num = "0" + debLine + ": ";
            else if(Integer.toString(debLine).length() == 3) num = debLine + ": ";
            else num = "999: ";
            
            System.out.println(num + mes);
            debLine++;
        }
    }
    
    public static void reportErr(String errMes)
    {
        if(Settings.useDebugging)
        {
            String num = null;
            if(Integer.toString(debLine).length() == 1) num = "00" + debLine + ": ";
            else if(Integer.toString(debLine).length() == 2) num = "0" + debLine + ": ";
            else if(Integer.toString(debLine).length() == 3) num = debLine + ": ";
            else num = "999: ";
            
            System.err.println(num + errMes);
            debLine++;
        }
    }

    public void focusGained(FocusEvent e)
    {
        if(e.getSource() == login && login.getText().equals(Settings.login_text)) login.setText("");
        if(e.getSource() == password && new String(password.getPassword()).equals(Settings.pass_text)) password.setText("");
    }

    public void focusLost(FocusEvent e)
    {
        if(e.getSource() == login && login.getText().equals("")) login.setText(Settings.login_text);
        if(e.getSource() == password && new String(password.getPassword()).equals("")) password.setText(Settings.pass_text);
    }
    
    public void keyTyped(KeyEvent e) {}
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e)
    {
        if (e.getKeyText(e.getKeyCode()).equals("Enter"))
        {
            if (panel.unit == 0) doAuth.doClick();
            else if (panel.unit == 4) toGame.doClick();
        }
    }
}
