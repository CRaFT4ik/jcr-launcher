package ru.er_log.components;

import java.awt.Color;
import ru.er_log.utils.BaseUtils;
import ru.er_log.utils.ImageUtils;

public class ThemeElements {
    
    public static Color tcolor;
    
    public static final ImageUtils loginImg		= new ImageUtils(0, 0, 232, 46, 0, 0, BaseUtils.authElTexture);
    public static final ImageUtils lineImg		= new ImageUtils(0, 0, 232, 1, 0, 46, BaseUtils.authElTexture);
    public static final ImageUtils pasImg		= new ImageUtils(0, 0, 232, 46, 0, 47, BaseUtils.authElTexture);
    public static final ImageUtils settings		= new ImageUtils(57, 272, 116, 46, 0, 93, 0, 139, 0, 185, BaseUtils.authElTexture);
    public static final ImageUtils doAuth		= new ImageUtils(173, 272, 116, 46, 116, 93, 116, 139, 116, 185, BaseUtils.authElTexture);
    
    public static final ImageUtils turn			= new ImageUtils(305, 8, 14, 14, 0, 0, 0, 14, 0, 28, BaseUtils.sysButs);
    public static final ImageUtils close		= new ImageUtils(325, 8, 14, 14, 14, 0, 14, 14, 14, 28, BaseUtils.sysButs);
    
}
