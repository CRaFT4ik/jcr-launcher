package ru.er_log.utils;

import java.awt.Color;
import ru.er_log.Settings;
import ru.er_log.components.Frame;
import ru.er_log.components.Panel;
import ru.er_log.components.ThemeElements;
import ru.er_log.components.PersonalCab;
import static ru.er_log.utils.BaseUtils.*;
import static ru.er_log.components.Frame.*;

public class StreamUtils {
    
    public static Thread t = null;
    
    public static void doLogin()
    {
        join(t);
        t = new Thread() {
            public void run()
            {
                report("Авторизация...");
                frame.settings.setEnabled(false);
                frame.doAuth.setEnabled(false);
                frame.panel.waitIcon(true);

                String auth = runHTTP(
                        getURLSc("jcr_auth.php")
                        , "?action=auth&login=" + frame.login.getText() + "&password=" + new String(frame.password.getPassword()) + "&hash=" + appHash + "&format=" + getProgramFormat() + "&client=" + getClientName() + "&code=" + GuardUtils.sha1(Settings.protectKey)
                        , true
                );

                BaseUtils.sleep(1.0);
                frame.panel.resetAlerts();
                
                if (auth == null)
                {
                    frame.setAlert("Ошибка подключения", 2);
                } else if (auth.trim().equals("BadParams") || auth.toLowerCase().contains("error"))
                {
                    frame.setAlert("Внутренняя ошибка", 2);
                    reportErr("Ошибка в переданных параметрах");
                } else if (auth.trim().equals("BadCode"))
                {
                    frame.setAlert("Внутренняя ошибка", 2);
                    reportErr("Неверный код доступа на web-сервер");
                } else if (auth.contains("<::>"))
                {
                    authData = auth.replaceAll("<br>", "").split("<::>");

                    BaseUtils.writeConfig();

                    frame.setAlert("Вход выполнен успешно", 1);
                    BaseUtils.sleep(1.0);

                    if (authData[8].equals("true")) definitionFrames();
                    else
                    {
                        Panel.updateBool = authData[5].equals(GuardUtils.sha1(Settings.version));
                        if (Panel.updateBool) frame.upd_action.setText("Продолжить");

                        frame.toXFrame(3);
                    }
                    
                    PersonalCab.setImages(authData);
                    frame.panel.repaint();
                } else
                {
                    frame.setAlert("Неверный логин или пароль", 3);
                }
                
                frame.settings.setEnabled(true);
                frame.doAuth.setEnabled(true);
            }
        }; t.setName("doLogin"); t.start();
    }
    
    public static void loadNewsPage(final String url)
    {
        final Color c = ThemeElements.tcolor;
        join(t);
        t = new Thread() {
            public void run()
            {
                Frame.report("Загрузка новостей...");
                try
                {
                    Frame.frame.news_pane.setPage(url);
                    Frame.report("Страница новостей загружена");
                } catch (Exception e)
                {
                    Frame.frame.news_pane.setText("<center><font color=\"rgb(" + c.getRed() + "," + c.getGreen() + "," + c.getBlue() + ")\" style=\"font-family: Arial, Tahoma, Helvetica, sans-serif\">Не удалось загрузить новости</font></center>");
                    Frame.reportErr("Ошибка при загрузке новостей");
                }
            }
        }; t.setName("loadNewsPage"); t.start();
    }
    
    public static void getServerOnline()
    {
        join(t);
        t = new Thread() {
            public void run()
            {
                try
                {
                    String server[] = getServerAbout();
                    String url = runHTTP(
                            getURLSc("jcr_status.php")
                            , "?action=status&ip=" + server[1] + "&port=" + server[2]
                            , false
                    );

                    frame.panel.resetAlerts();

                    if (url == null)
                    {
                        reportErr("Ошибка подключения к серверу: " + url);
                        frame.setAlert("Ошибка подключения", 2);
                        frame.panel.waitIcon(false);
                    } else if (url.contains("<::>"))
                    {
                        String[] result = url.split("<::>");
                        if (new Integer(result[0]) >= new Integer(result[1]))
                        {
                            frame.setAlert("Сервер полон: " + result[0] + " из " + result[1], 3);
                        } else
                        {
                            frame.setAlert("Сервер доступен: " + result[0] + " из " + result[1], 1);
                        }
                        frame.panel.waitIcon(false);
                    } else if (url.trim().equals("OFF"))
                    {
                        frame.setAlert("Сервер недоступен", 2);
                        frame.panel.waitIcon(false);
                    } else if (url.trim().equals("TechWork"))
                    {
                        frame.setAlert("Технические работы", 3);
                        frame.panel.waitIcon(false);
                    } else
                    {
                        reportErr("Внутренняя ошибка");
                        frame.setAlert("Внутренняя ошибка", 2);
                    }
                } catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }; t.setName("getServerOnline"); t.start();
    }

    public static void setAppHash()
    {
        join(t);
        t = new Thread() {
            public void run()
            {
                String readyMD5 = GuardUtils.md5_file(GuardUtils.appPath());
                if (!readyMD5.isEmpty()) appHash = readyMD5;
            }
        }; t.setName("setAppHash"); t.start();
    }

    public static void actionTakeUpdate()
    {
        join(t);
        t = new Thread() {
            public void run()
            {
                try
                {
                    frame.upd_take.setEnabled(false);
                    frame.panel.waitIcon(true, 382);
                    frame.setAlert("", 0);
                    BaseUtils.sleep(1.0);
                    updateProgram();
                } catch (Exception e)
                {
                    frame.setAlert("Ошибка при обновлении", 3, 391);
                    reportErr("Ошибка при обновлении программы");
                    
                    frame.upd_take.setEnabled(true);
                    frame.upd_take.setText("Еще раз");
                    
                    frame.panel.waitIcon(false);
                }
            }
        }; t.setName("actionTakeUpdate"); t.start();
    }
    
    public static void join(Thread t)
    {
        if (t != null)
        {
            try { t.join(); }
            catch (InterruptedException ex)
            { Frame.report("Не удалось дождаться завершения потока: " + t.getName()); }
        }
    }
}
