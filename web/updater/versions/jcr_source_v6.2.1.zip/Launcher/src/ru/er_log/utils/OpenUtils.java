package ru.er_log.utils;

public class OpenUtils {

}
