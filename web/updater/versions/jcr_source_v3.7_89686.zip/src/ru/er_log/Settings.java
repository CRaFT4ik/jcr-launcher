package ru.er_log;

import ru.er_log.components.UI_Theme;
import ru.er_log.themes.*;


public class Settings {
    
    /**
     * * * На заметку: ...
     * 
     * * Обновление программы.
     * При том, как вы обновите лаунчер и загрузите его на сервер,
     * старый лаунчер обязательно предолжит обновление игрокам.
     * Если вы не изменяли версию нового лаунчера (т.е. она совпадает с версией старого в веб-части),
     * обновление будет не принудительным и игроки смогут пропустить его.
     * Если версия нового лаунчера изменена, игрок не сможет продолжить свои
     * действия, пока не обновит лаунчер.
     * 
     * * Online тема.
     * Online тема можеть быть загружена с сервера только в том случае,
     * если версия текущей программы совпадает с версией программы на сервере.
     * 
     * * Возможности и особенности программы:
     * - Авторизация.
     * - Защита сессии (скрывает сессию от WireShark и других подобных программ).
     * - Мощный античит (проверка модов и jar'ников, их хеш-сумм).
     * - Загрузка и проверка папки "coremods", которую создает Forge.
     * - Поддержка Forge.
     * - Мониторинг серверов (работает и со Spigot серверами).
     * - Отладчик (отображение всех действий программы в консоли).
     * - Мультиклиентность.
     * - Мультисерверность.
     * - Загрузка новостей.
     * - Выделение памяти.
     * - Умное самообновление (подробнее в инструкции).
     * - Автоматический патчинг клиента (во избежании использования стандартной папки ".minecraft").
     * - Загрузка online темы (хорошо продумана, вы можете использовать её без опаски).
     * - Личный кабинет (skins and cloaks, revision...).
     * - Загрузка и распаковка архива с файлами в директорию с клиентом (extra.zip).
     * - Окно заставки перед запуском (оптимально для online темы).
     * - Анимация переходов между окнами (затемнение и осветление).
     * - Надежное шифрование паролей.
     * - Online настройки (веб часть - очень удобно, без необходимости обновлять программу).
     * - Шрифты, читаемые из файла (по умолчанию поддержка 2-х шрифтов).
     * - При запуске программы в формате ".exe" функция самообновления будет скачивать и запускать программу именно в этом формате, а не в формате ".jar" (аналогично с форматом ".jar").
     * - Аккуратное, небольшое окно, которое позволяет вписать в себя все необходимое.
     * - Возможность полного легкого изменения дизайна (изображения).
     * - Отображение скинов и плащей любых размеров с соблюдением пропорций (объемный шлем, как и в игре).
     * 
     */
    
    /* Основные настройки программы */
    public static final String title			= "JCR Launcher"; // Название окна программы
    public static final String titleInGame		= "Minecraft"; // Название окна программы после запуска игры
    public static final String version			= "v2.1"; // Версия программы (не используйте символ пробела)
    
    public static final String parDirectory		= "AppData"; // Родительская папка для Minecraft (только для Windows) [ProgramFiles, AppData]
    public static final String gameDirectory		= ".jcr_launcher"; // Папка с Minecraft (.minecraft)
    
    /* Настройки подключения */
    public static final String domain			= "er-log.ru"; // Домен сайта в формате: example.com
    public static final String siteDir			= "JCR_Launcher"; // Директория к папке программы от корня сайта
    public static final String protectKey		= "y@Ur_'k[e]Y"; // Ключ защиты доступа к веб-части (равен ключу в веб-части). Пример: 17@Ee'45x_Fq;04
    
     // Надпись под логотипом, Размер шрифта, Номер шрифта (в файле настроек темы)
    public static final String[] strUnderLogo =
    {
        "JCR Launcher " + version, "18", "#2"
    };
    
    public static final String login_text		= "Логин"; 		// Начальный текст поля для логина
    public static final String pass_text		= "Пароль"; 		// Начальный текст поля для пароля
    
    public static final String offUser			= "Player"; 		// Имя пользователя одиночной игры
    public static final String offSess			= "123456"; 		// Сессия пользователя для одиночной игры
    
    /* Глобальные параметры программы */
    public static final boolean useSplashScreen		= true; 		// Использовать заставку пред запуском (оптимально для online темы)
    public static final boolean useSysFrame		= false; 		// Использовать системный фрейм (системная рамка вокруг окна)
    public static final boolean useAnimation		= true; 		// Использовать анимацию переходов между окнами в программе
        public static final int animationSpeed		    = 15; 		    // Скорость анимации переходов между окнами (в разумных пределах от 10 до 30)
        
    public static final UI_Theme currentTheme		= new JCR_Theme(); 	// Название темы программы (имя файла темы)
    public static final int logoIndent			= 67; 			// Положение логотипа относительно оси Y
    
    /* Основные параметры программы */
    public static final boolean usePersonal		= true; 		// Использовать личный кабинет пользователя (Внимание! Кабинет в разработке! В данный момент присутствует только вывод скина и плаща)
    public static final boolean useUpdateMon		= false; 		// Автоматически загружать статус текущего сервера при запуске программы
    public static final boolean useMultiClient		= false; 		// Мультиклиентность (использовать автовход на выбранный сервер после авторизации, своя подпапка для каждого сервера)
        public static final String mainClientDir	    = "main_client"; 	    // В случае, если мультиклиентность выключена, основной клиент будет закачан в эту папку (можно оставить пустым)
    public static final boolean useRememPass		= false; 		// Использовать функцию запоминания пароля (помимо логина)
    public static final boolean useLoadingNews		= true; 		// Загружать новости и отображать их в личном кабинете игрока
        // Скорость анимации выезда новостей
        public static final int newsDrawingTime             = 50; 		    // Таймер прорисовки. Каждые [n] секунд прорисовывать окно (чем больше значение смещения (ниже), тем меньше должно быть значение таймера прорисовки)
        public static final int newsOffsetPanel             = 5; 		    // Смещение. Каждые [n] секунд (выше) смещать окно на [x] пикселей (Внимание! Должно быть кратно ширине новостной панели (300))
    
    /* Параметры функции "GUARD" в программе */
    public static final boolean useModsDelete		= false; 		// Удалять папку mods при запуске игры (при хранении модификаций в minecraft.jar)
    public static final boolean useModCheck		= true; 		// Использовать проверку модов
        public static final boolean useCheckModsHashes      = true;                 // Сверять хеши модов с оригинальными
        public static final boolean stopDirtyProgram	    = true; 		    // Завершать работу программы после обнаружения сторонних модификаций и их удаления
        public static final boolean removeAllFiles	    = false; 		    // Удалять абсолютно все сторонние обнаруженные файлы в папке "mods" (или же только файлы модов и папки)
        public static final boolean useModCheckTimer	    = true; 		    // Каждые [n] секунд (ниже) производить перепроверку модов
        public static final int timeForModsCheck	    = 30; 		    // Время (в секундах), после которого будет произведена перепроверка модов
    
    public static final boolean pathClient		= true; 		// Использовать автоматическую замену директории в клиенте (во избежании использования стандартной папки .minecraft)
    public static final String mcMineClass = "net.minecraft.client.Minecraft"; 	// Главный класс Minecraft (используется при патчинге клиента)
    
    /* Настройки отладки */
    public static final boolean useDebugging		= true; 		// Режим отладки (вывод сообщений в консоль), рекомендуется отключить после завершения установки настроек
    public static final boolean useHDebuggingMode	= true; 		// Производить отладку после запуска игры
    public static final boolean drawBorders		= false; 		// Отрисовка границы элементов программы
    
    /* Настройки окна заставки (для опытных) */
    public static final int splashWidth			= 280; 			// Ширина окна заставки
    public static final int splashHeight		= 200; 			// Высота окна заставки
    public static final int splashXAlign		= 30; 			// Положение статуса на заставке относительно оси X
    public static final int splashYAlign		= 172; 			// Положение статуса на заставке относительно оси Y
    
    /* Блокированные настройки */
    public static final int frameWidth			= 346; 			// Ширина фрейма [346]
    public static final int frameHeight			= 450; 			// Высота фрейма [450]
}
