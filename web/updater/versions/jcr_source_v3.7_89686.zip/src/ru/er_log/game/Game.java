package ru.er_log.game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.Timer;

import net.minecraft.Launcher;
import ru.er_log.Settings;
import ru.er_log.components.Frame;
import ru.er_log.utils.BaseUtils;
import ru.er_log.utils.GuardUtils;

public class Game extends JFrame {

    public static Launcher applet;

    public Game(final String[] data)
    {
        String username = Frame.frame.set_offline.isSelected() ? Settings.offUser : Frame.frame.login.getText();
        String session_num = Frame.frame.set_offline.isSelected() ? Settings.offSess + "<::>null" : GuardUtils.md5(data[7]) + "<::>" + BaseUtils.getClientName() + "<::>" + BaseUtils.getClientDirectory();
        
        GuardUtils.checkClient(Frame.authData, true);
        
        if (Settings.useModCheck && Settings.useModCheckTimer)
        {
            new Timer(Settings.timeForModsCheck * 1000, new ActionListener() {
                public void actionPerformed(ActionEvent e)
                {
                    GuardUtils.checkClient(Frame.authData, false);
                }
            }).start();
        }
        
        try
        {
            addWindowListener(new WindowListener() {
                public void windowOpened(WindowEvent e) {}
                public void windowIconified(WindowEvent e) {}
                public void windowDeiconified(WindowEvent e) {}
                public void windowDeactivated(WindowEvent e) {}
                public void windowClosed(WindowEvent e) {}
                public void windowActivated(WindowEvent e) {}
                public void windowClosing(WindowEvent e)
                {
                    applet.stop();
                    applet.destroy();
                    System.exit(0);
                }
            });

            String bin = BaseUtils.getClientDirectory() + File.separator + "bin" + File.separator;
            setForeground(Color.BLACK);
            setBackground(Color.BLACK);
            URL[] urls = new URL[4];
            urls[0] = new File(bin, "minecraft.jar").toURI().toURL();
            urls[1] = new File(bin, "lwjgl.jar").toURI().toURL();
            urls[2] = new File(bin, "jinput.jar").toURI().toURL();
            urls[3] = new File(bin, "lwjgl_util.jar").toURI().toURL();

            applet = new Launcher(bin, urls);
            applet.customParameters.put("username", username);
            applet.customParameters.put("sessionid", session_num);
            applet.customParameters.put("stand-alone", "true");
            if (Settings.useMultiClient && !Frame.frame.set_offline.isSelected())
            {
                applet.customParameters.put("server", BaseUtils.getServerAbout()[1]);
                applet.customParameters.put("port", BaseUtils.getServerAbout()[2]);
            }
            
            setTitle(Settings.titleInGame);
            Frame.frame.setVisible(false);
            setSize(880, 520);
            setMinimumSize(new Dimension(880, 520));
            setLocationRelativeTo(null);
            
            applet.setForeground(Color.BLACK);
            applet.setBackground(Color.BLACK);
            setLayout(new BorderLayout());
            add(applet, BorderLayout.CENTER);
            validate();
            if (BaseUtils.getPropertyBoolean("full_screen"))
                setExtendedState(JFrame.MAXIMIZED_BOTH);
            setIconImage(BaseUtils.openImage(BaseUtils.getTheme().themeGameIcon()));
            setVisible(true);

            if (!Settings.useHDebuggingMode)
            {
                System.setErr(new PrintStream(new NulledStream()));
                System.setOut(new PrintStream(new NulledStream()));
            }
            applet.init();
            applet.start();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

class NulledStream extends OutputStream {

    public void write(int b) throws IOException {}
}
