package ru.er_log;

import java.util.ArrayList;

import ru.er_log.splash.SplashScreen;
import ru.er_log.utils.BaseUtils;
import ru.er_log.utils.GuardUtils;

public class Starter {

    public static void main(String[] args) throws Exception
    {
        try
        {
            String apppath = GuardUtils.appPath();
            int memory = BaseUtils.getPropertyInt("memory");
            if (memory == 0) memory = 1024;

            ArrayList<String> params = new ArrayList<>();

            if (BaseUtils.getPlatform() == 2)
                params.add("javaw");
            else
                params.add("java");
            params.add("-Xmx" + memory + "m");
            params.add("-Xms" + memory + "m");
            params.add("-Dsun.java2d.noddraw=true");
            params.add("-Dsun.java2d.d3d=false");
            params.add("-Dsun.java2d.opengl=false");
            params.add("-Dsun.java2d.pmoffscreen=false");
            params.add("-classpath");
            params.add(apppath);
            params.add("ru.er_log.Main");

            ProcessBuilder pb = new ProcessBuilder(params);
            Process process = pb.start();
            if (process == null)
                throw new Exception("Не удалось запустить программу!");
            
            System.exit(0);
        } catch (Exception e)
        {
            e.printStackTrace();
            SplashScreen.start();
        }
    }
}