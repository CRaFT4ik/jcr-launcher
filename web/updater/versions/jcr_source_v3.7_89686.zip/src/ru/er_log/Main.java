package ru.er_log;

import ru.er_log.splash.SplashScreen;

public class Main {

    public static void main(String[] args) throws Exception
    {
        SplashScreen.start();
    }
}
