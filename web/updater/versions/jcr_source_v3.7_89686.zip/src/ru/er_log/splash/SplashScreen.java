package ru.er_log.splash;

import java.lang.reflect.InvocationTargetException;
import javax.swing.SwingUtilities;
import ru.er_log.Settings;
import ru.er_log.components.Frame;

public class SplashScreen {

    private static SplashFrame sframe;

    public static void start()
    {
        if (Settings.useSplashScreen) createSplash();
        beforeStart();
        createMainFrame();
    }
    
    private static final void createSplash()
    {
        Frame.report("Подготовка к запуску программы...");
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                sframe = new SplashFrame();
                sframe.show();
            }
        });
    }
    
    private static final void beforeStart()
    {
        status("загрузка изображений...");
        
        Frame.beforeStart();
        
        status("запуск программы...");
    }
    
    private static final void createMainFrame()
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run() { Frame.start(sframe); }
        });
    }
    
    private static final void status(final String status)
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            { public void run() { sframe.setStatus(status); } });
        } catch (InterruptedException | InvocationTargetException e) {}
    }
}