package ru.er_log.components;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPasswordField;
import ru.er_log.Settings;
import ru.er_log.utils.StyleUtils;

public class PassField extends JPasswordField {
    
    public Panel pb;
    public int width = 0;
    public int height = 0;
    public int x = 0;
    public int y = 0;
    
    public PassField(int x, int y, int width, int height, Color color)
    { 
	setOpaque(false);
	setBorder(null);
	setCaretColor(color);
	setForeground(color);
        setSelectionColor(new Color(51, 153, 255));
        setSelectedTextColor(Color.WHITE);
        setHorizontalAlignment(LEFT);
        setFont(StyleUtils.getFont(14, 1));
        setBounds(x+16, y, width-32, height);
        
        this.width  = width - 32;
        this.height = height;
        this.x = x;
        this.y = y;
        
        pb = new Panel();
        pb.DrawPasswordField(y);
    }
    
    protected void paintComponent(Graphics mainG)
    {
        Graphics2D g = (Graphics2D) mainG.create();
        
        if(Settings.drawBorders)
        {
            g.setColor(Color.GRAY);
            g.drawRect(0, 0, width - 1, height - 1);
        }
        g.dispose();
        super.paintComponent(mainG);
    }
}
