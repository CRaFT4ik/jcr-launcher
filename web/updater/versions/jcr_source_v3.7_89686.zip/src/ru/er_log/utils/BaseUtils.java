package ru.er_log.utils;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import net.minecraft.Launcher;
import ru.er_log.components.Frame;
import ru.er_log.Settings;
import ru.er_log.Starter;
import ru.er_log.components.ThemeElements;
import ru.er_log.components.UI_Theme;
import ru.er_log.game.GameUpdater;

public class BaseUtils {

    public static Launcher launcher;
    public static GameUpdater gameUpdater;
    public static final ConfigUtils config = new ConfigUtils("config", getParentDirectory());
    
    public static String[] servers = null;
    public static boolean offlineTheme = false;
    
    public static BufferedImage favicon, background, logotype, authElTexture,
            sysButs, button, combobox, checkbox, fieldBack, progBarImage,
            modalBack, news_back, pressBorder, waitIcon, alertIcons, bandColors, def_skin;
    
    public static BufferedImage openImage(String name)
    {
        try
        {
            BufferedImage img = ImageIO.read(BaseUtils.class.getResource(getTheme().themeDirectory() + name));
            Frame.report("Открыто локальное изображение: " + name);
            return img;
        } catch (Exception e)
        {
            Frame.reportErr("Ошибка при открытии изображения: " + name);
            return new BufferedImage(1, 1, 2);
        }
    }

    public static String runHTTP(String URL, String params, boolean send)
    {
        HttpURLConnection ct = null;
        try
        {
            if (send) Frame.report("Утановка соединения с: " + URL + params);

            URL url = new URL(URL + params);
            ct = (HttpURLConnection) url.openConnection();
            ct.setRequestMethod("POST");
            ct.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            ct.setRequestProperty("Content-Length", "0");
            ct.setRequestProperty("Content-Language", "en-US");
            ct.setUseCaches(false);
            ct.setDoInput(true);
            ct.setDoOutput(true);

            ct.connect();

            InputStream is = ct.getInputStream();
            StringBuilder response;
            try (BufferedReader rd = new BufferedReader(new InputStreamReader(is)))
            {
                response = new StringBuilder();
                String line;
                while ((line = rd.readLine()) != null)
                {
                    response.append(line);
                }
            }

            String str = response.toString();

            if (send) Frame.report("Соединение установлено. Получен ответ: '" + str + "'");
            return str;
        } catch (Exception e)
        {
            if (send) Frame.reportErr("Не удалось установить соединение с: " + URL + ", возвращаю null");
            return null;
        } finally
        {
            if (ct != null) ct.disconnect();
        }
    }

    public static void sleep(double second)
    {
        try
        {
            Thread.sleep((long) (second * 1000));
        } catch (Exception e) {}
    }

    public static UI_Theme getTheme()
    {
        return Settings.currentTheme;
    }
    
    public static void setTheme()
    {
        String script = "jcr_theme.php?action=theme&version=" + Settings.version + "&request=";
        
        try
        {
            if (useOnlineTheme())
            {
                Frame.report("Загужаю online тему...");
                
                String imgList[] = Frame.onlineData[1].split("<:i:>");
                for (int i = 0; i < imgList.length; i++)
                {
                    setThemeImages(loadImageIO(getURLSc(script), imgList[i]), i);
                    if (offlineTheme) break;
                }
                
                if (!offlineTheme) Frame.report("Online тема успешо загружена");
                else Frame.reportErr("Не удалось загрузить элементы online темы, запускаю тему по умолчанию");
            } else offlineTheme = true;
        } catch (Exception e)
        {
            offlineTheme = true;
            Frame.reportErr("Не удалось загрузить online тему, запускаю тему по умолчанию");
        }
        
        if (offlineTheme)
        {
            setThemeImages(null, -1);
            ThemeElements.tcolor = Color.decode(getTheme().themeFieldsStyle());
        } else
            ThemeElements.tcolor = StyleUtils.getOnlineThemeColor();
    }
    
    public static BufferedImage loadImageIO(String url, String name) throws Exception
    {
        BufferedImage img = null;
        try
        {
            img = ImageIO.read(new URL(url + name));
            Frame.report(" * Загружено изображение: " + name); return img;
        } catch (Exception e)
        {
            Frame.reportErr(" * Загрузка прервана на элементе: " + name);
            offlineTheme = true;
            return null;
        }
    }
    
    public static void setThemeImages(BufferedImage img, int num)
    {
        if (img == null && num == -1)
        {
            favicon		= openImage(getTheme().themeFavicon());
            background		= openImage(getTheme().themeBackground());
            logotype		= openImage(getTheme().themeLogotype());
            authElTexture	= openImage(getTheme().themeAuthElements());
            sysButs		= openImage(getTheme().themeSysButs());
            button		= openImage(getTheme().themeButton());
            combobox		= openImage(getTheme().themeComboBox());
            checkbox		= openImage(getTheme().themeCheckBox());
            fieldBack		= openImage(getTheme().themeFieldBack());
            progBarImage	= openImage(getTheme().themeProgressBar());
            modalBack		= openImage(getTheme().themeModalBack());
            news_back		= openImage(getTheme().themeNewsBack());
            pressBorder		= openImage(getTheme().themePressedBorder());
            waitIcon		= openImage(getTheme().themeWaitIcon());
            alertIcons		= openImage(getTheme().themeAlertIcons());
            bandColors		= openImage(getTheme().themeBandColors());
        } else
        {
            switch (num)
            {
                case 0: favicon = img;
                case 1: background = img;
                case 2: logotype = img;
                case 3: authElTexture = img;
                case 4: sysButs = img;
                case 5: button = img;
                case 6: combobox = img;
                case 7: checkbox = img;
                case 8: fieldBack = img;
                case 9: progBarImage = img;
                case 10: modalBack = img;
                case 11: news_back = img;
                case 12: pressBorder = img;
                case 13: waitIcon = img;
                case 14: alertIcons = img;
                case 15: bandColors = img;
            }
        }
        
        def_skin = openImage("char.png");
    }
    
    public static String getURL(String path)
    {
        return "http://" + Settings.domain + "/" + Settings.siteDir + "/" + path;
    }
    
    public static String getURLSc(String script)
    {
        return getURL("scripts/" + script);
    }
    
    public static String getURLFi(String folder)
    {
        return getURL("files/" + folder);
    }
    
    public static String[] loadOnlineSettings()
    {
        Frame.report("Загрузка online настроек...");
        try
        {
            String url = runHTTP(getURLSc("jcr_theme.php"), "?action=settings&request=elements&version=" + Settings.version, false);
            
            if (url == null)
            {
                Frame.reportErr("Не удалось загрузить online настройки");
                return null;
            } else if (url.contains("<::>"))
            {
                return url.replaceAll("<br>", "").split("<::>");
            } else
            {
                Frame.reportErr("Не удалось загрузить online настройки");
                return null;
            }
        } catch (Exception e)
        {
            Frame.reportErr("Не удалось загрузить online настройки");
            return null;
        }
    }
    
    public static boolean useOnlineTheme()
    {
        try
        {
            if (Frame.onlineData[0].equals("true")) return true;
            else return false;
        } catch (Exception e) { return false; }
    }
    
    public static String[] getServersNames()
    {
        String[] error = { "Ошибка подключения", "error" };
        try
        {
            String url = runHTTP(getURLSc("jcr_status.php"), "?action=servers", false);

            if (url == null)
            {
                Frame.reportErr("Не удалось загрузить список серверов");
                return error;
            } else if (url.contains(" :: "))
            {
                servers = url.replaceAll("<br>", "").split("<::>");
                String[] serversNames = new String[servers.length];

                for (int a = 0; a < servers.length; a++)
                {
                    serversNames[a] = servers[a].split(" :: ")[0];
                }

                return serversNames;
            } else
            {
                Frame.reportErr("Не удалось загрузить список серверов");
                return error;
            }
        } catch (Exception e)
        {
            Frame.reportErr("Не удалось загрузить список серверов");
            return error;
        }
    }

    public static String[] getServerAbout()
    {
        int index = Frame.frame.serversList.getSelectedIndex();
        
        if (servers != null)
            return servers[index].split(" :: ");
        return null;
    }

    public static String getClientName()
    {
        String[] server = getServerAbout();
        
        if(server != null)
            return (server[1] + "_" + server[2]).toLowerCase();
        return null;
    }
    
    public static String getParentDirectory()
    {
        return getDirectory(Settings.gameDirectory) + "";
    }
    
    public static String getClientFolder()
    {
        if(Settings.useMultiClient)
            return getClientName();
        return Settings.mainClientDir;
    }
    
    public static String getClientDirectory()
    {
        String dir = getDirectory(Settings.gameDirectory).toString();
        return dir + File.separator + getClientFolder();
    }
    
    private static File getDirectory(String gameDirectory)
    {
        String home = System.getProperty("user.home", ".");
        File fiDir;
        switch (getPlatform())
        {
            case 0:
            case 1:
                fiDir = new File(System.getProperty("user.home", "."), gameDirectory + File.separator);
                break;
            case 2:
                String appData = System.getenv(Settings.parDirectory);
                if (appData != null)
                    fiDir = new File(appData, gameDirectory + File.separator);
                else
                    fiDir = new File(home, gameDirectory + File.separator);
                break;
            case 3:
                fiDir = new File(home, "Library/Application Support/" + gameDirectory + File.separator);
                break;
            default:
                fiDir = new File(home, gameDirectory + File.separator);
        }
        if (!fiDir.exists() && !fiDir.mkdirs())
        {
            Frame.reportErr("Директория не найдена: " + fiDir);
        }
        return fiDir;
    }
    
    public static int getPlatform()
    {
        String osName = System.getProperty("os.name").toLowerCase();

        if (osName.contains("win"))
            return 2;
        if (osName.contains("mac"))
            return 3;
        if (osName.contains("solaris"))
            return 1;
        if (osName.contains("sunos"))
            return 1;
        if (osName.contains("linux"))
            return 0;
        if (osName.contains("unix"))
            return 0;

        return 4;
    }
    
    static { config.load(); }
    
    public static void setProperty(String s, Object value)
    {
        if (config.checkProperty(s))
            config.changeProperty(s, value);
        else config.put(s, value);
    }
    
    public static void deleteProperty(String s)
    {
        if (config.checkProperty(s))
            config.deleteProperty(s);
    }
    
    public static String getPropertyString(String s)
    {
        if (config.checkProperty(s))
            return config.getPropertyString(s);
        return null;
    }

    public static boolean getPropertyBoolean(String s)
    {
        if (config.checkProperty(s))
            return config.getPropertyBoolean(s);
        return false;
    }

    public static int getPropertyInt(String s)
    {
        if (config.checkProperty(s))
            return config.getPropertyInteger(s);
        return 0;
    }
    
    public static void writeConfig()
    {
        Frame frame = Frame.frame;
        
        if (frame.set_remember.isSelected())
        {
            setProperty("login", EncodingUtils.encode(frame.login.getText()));
            if (Settings.useRememPass)
                setProperty("password", EncodingUtils.encode(new String(frame.password.getPassword())));
            
            setProperty("server", frame.serversList.getSelectedIndex());
        } else
        {
            deleteProperty("login");
            if (Settings.useRememPass)
                deleteProperty("password");
        }
        
        int remPr;
        if (frame.set_remember.isSelected()) remPr = 1; else remPr = 2;
        setProperty("remember", remPr);
        
        setProperty("full_screen", frame.set_full.isSelected());
    }
    
    public static void readConfig(final Frame frame)
    {
        String loginPr = EncodingUtils.decode(getPropertyString("login"));
        if (!loginPr.equals("")) frame.login.setText(loginPr);
        
        if (Settings.useRememPass)
        {
            String passPr = EncodingUtils.decode(getPropertyString("password"));
            if (!passPr.isEmpty()) frame.password.setText(passPr);
        }
        
        int serversListPr = getPropertyInt("server");
        if (servers != null && serversListPr <= servers.length)
            frame.serversList.setSelectedIndex(serversListPr);
        
        int remPr = getPropertyInt("remember");
        if (remPr == 0 || remPr == 1) frame.set_remember.setSelected(true);
        else frame.set_remember.setSelected(false);
        
        frame.set_full.setSelected(getPropertyBoolean("full_screen"));
        
        int memory = getPropertyInt("memory");
        if (memory >= 256) frame.set_memory.setText(memory+"");
    }
    
    public static void definitionFrames()
    {
        if (Settings.usePersonal) Frame.frame.toXFrame(5);
        else toLaunchGame();
    }
    
    public static void toLaunchGame()
    {
        if (Frame.frame.set_update.isSelected())
        {
            deleteProperty(getClientName() + "_hashZip");
            delete(new File(getClientDirectory()));
        }
        
        boolean zipupdate = false;
        String[] data = Frame.authData;
        String[] mods = data[9].split("<:m:>");
        String[] coremods = data[13].split("<:m:>");
        String[] natives = data[15].split("<:n:>");
        List<String> files = new ArrayList<>();
        
        String binfolder = getClientDirectory() + File.separator + "bin" + File.separator;
        String modsfolder = getClientDirectory() + File.separator + "mods" + File.separator;
        String coremodsfolder = getClientDirectory() + File.separator + "coremods" + File.separator;
        String natsfolder = binfolder + "natives" + File.separator;
        
        if (!natives[0].equals("nonatives") && !new File(natsfolder).exists() || new File(natsfolder).listFiles().length == 0)
            for (int i = 0; i < natives.length; i++)
                if (!new File(natsfolder + natives[i]).exists())
                    files.add("bin/natives/" + natives[i]);
        if (!data[0].equals(getPropertyString(getClientName() + "_hashZip"))) { files.add("extra.zip"); zipupdate = true; }
        if (!data[1].equals(GuardUtils.md5_file(binfolder + "minecraft.jar"))) files.add("bin/minecraft.jar");
        if (!data[2].equals(GuardUtils.md5_file(binfolder + "lwjgl.jar"))) files.add("bin/lwjgl.jar");
        if (!data[3].equals(GuardUtils.md5_file(binfolder + "lwjgl_util.jar"))) files.add("bin/lwjgl_util.jar");
        if (!data[4].equals(GuardUtils.md5_file(binfolder + "jinput.jar"))) files.add("bin/jinput.jar");
        
        if (!mods[0].equals("nomods"))
        for (int i = 0; i < mods.length; i++)
        {
            String[] mHash = mods[i].split("<:h:>");
            if (!mHash[1].equals(GuardUtils.md5_file(modsfolder + mHash[0]))) files.add("mods/" + mHash[0]);
        }
        
        if (!coremods[0].equals("nocoremods"))
        for (int i = 0; i < coremods.length; i++)
        {
            String[] mHash = coremods[i].split("<:h:>");
            if (!mHash[1].equals(GuardUtils.md5_file(coremodsfolder + mHash[0]))) files.add("coremods/" + mHash[0]);
        }
        
        if (!files.isEmpty())
        {
            Frame.report("Список загружаемых файлов: ");
            for (Object s : files.toArray()) Frame.report(" * " + s.toString());
        }
        
        gameUpdater = new GameUpdater(files, zipupdate, data);
        
        Frame.frame.toXFrame(4);
        if (Settings.useLoadingNews) Frame.frame.setSize(Settings.frameWidth, Settings.frameHeight);
        
        gameUpdater.start();
    }
    
    public static void openLink(String url)
    {
        try
        {
            Object o = Class.forName("java.awt.Desktop").getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
            o.getClass().getMethod("browse", new Class[] { URI.class }).invoke(o, new Object[] { new URI(url) });
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | URISyntaxException e)
        { Frame.reportErr("Не удалось открыть ссылку: " + url); }
    }
    
    public static void delete(File file)
    {
        try {
            if (!file.exists()) return;
            if (file.isDirectory())
            {
                for (File f : file.listFiles()) delete(f);
                file.delete();
            } else file.delete();
        } catch (Exception e)
        { Frame.reportErr("Удаление не удалось: " + file.toString()); }
    }
    
    public static void patchClient(URLClassLoader cl)
    {
        try
        {
            String mcver = getServerAbout()[3];
            String[] library = Frame.authData[10].split("<:f:>");
            
            Frame.report("Запуск процесса патчинга: ");
            Frame.report(" * Обнаружение клиента...");
            Frame.report(" * Клиент: " + getClientName() + " :: " + mcver);
            Frame.report(" * Поиск версии в библиотеке...");

            for (int j = 0; j < library.length; j++)
            {
                if (mcver.contains(library[j].split("::")[0].replace("x", "")))
                {
                    Frame.report(" * Патчинг клиента...");
                    Field f = cl.loadClass(Settings.mcMineClass).getDeclaredField(library[j].split("::")[1]);
                    Field.setAccessible(new Field[] { f }, true);
                    f.set(null, new File(getClientDirectory()));
                    Frame.report(" * Файл пропатчен: " + Settings.mcMineClass + " :: " + library[j].split("::")[1]);
                    Frame.report(" * Патчинг клиента успешно завершен");
                    return;
                }
            }
            
            Frame.reportErr(" * Данная версия клиента не обнаружена!");
            Frame.reportErr(" * Не удалось произвести патчинг клиента");
        } catch (Exception e)
        {
            Frame.reportErr(" * Ошибка: поле клиента не корректно");
        }
    }
    
    public static void updateProgram() throws Exception
    {
        Frame.report("Запуск процесса обновления программы...");
        
        String appURL = getURLFi("program/" + Frame.authData[14]);
        Frame.report("Загрузка файла: " + appURL);
        
        InputStream is = new BufferedInputStream(new URL(appURL).openStream());
        FileOutputStream fos = new FileOutputStream(GuardUtils.appPath());

        int bs = 0;
        byte[] buffer = new byte[65536];
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        while ((bs = is.read(buffer, 0, buffer.length)) != -1)
        {
            fos.write(buffer, 0, bs);
            md5.update(buffer, 0, bs);
        }
        is.close();
        fos.close();
        Frame.report("Файл загружен: " + appURL);
        
        if (getPlatform() == 3)
        {
            Frame.report("Обновление завершено успешно");
            Frame.frame.panel.waitIcon(false);
            Frame.frame.upd_action.setEnabled(false);
            Frame.frame.upd_take.setEnabled(false);
            Frame.frame.setAlert("Требуется перезапуск", 1, 391);
            Frame.report("Требуется перезапуск программы");
        } else
        {
            Starter.main(null);
            System.exit(0);
        }
    }
    
    public static String getProgramFormat()
    {
        String[] format = { ".jar", ".exe" };
        String path = GuardUtils.appPath().toLowerCase();
        if (path.substring(path.lastIndexOf("/")).contains(format[1]))
            return format[1];
        else
            return format[0];
    }
    
    public static void restart()
    {
        Frame.report("Перезапуск программы...");
        try { Starter.main(null); }
        catch (Exception e) { e.printStackTrace(); return; }
        System.exit(0);
    }
    
    public static int findString(String[] array, String str)
    {
        for (int a = 0; a < array.length; a++)
            for (int b = 0; b < array.length; b++)
                if (array[a].equals(str)) return a;
        
        return -1;
    }
    
    public static long random(long from, long to)
    {
        Random random = new Random();
        return from + Math.abs(random.nextLong()) % (to - (from - 1));
    }
}
